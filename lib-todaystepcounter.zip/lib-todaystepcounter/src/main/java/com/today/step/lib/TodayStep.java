package com.today.step.lib;

public class TodayStep {
    public static String unKownKeyButImportant = "";
    public static String MainAppid = "";
    public static void init(String appid, String sign) {
        MainAppid = appid;
        unKownKeyButImportant = sign;
    }
}
