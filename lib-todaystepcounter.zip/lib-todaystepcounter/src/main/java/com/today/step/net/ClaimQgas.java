package com.today.step.net;

public class ClaimQgas extends BaseBack {

    /**
     * claimedQgas : 0
     */

    private float claimedQgas;

    public float getClaimedQgas() {
        return claimedQgas;
    }

    public void setClaimedQgas(float claimedQgas) {
        this.claimedQgas = claimedQgas;
    }
}
